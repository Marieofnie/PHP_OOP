import "./reset.css";
import "./style.css";

console.log("Javascript werkt");
