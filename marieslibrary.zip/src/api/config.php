<?php function connectToDB()
{
    $DB_HOST = "ID396978_oopbooks.db.webhosting.be";
    $DB_USER = "ID396978_oopbooks";
    $DB_PASSWORD = "834G388W7F2lE7r1K838";
    $DB_DB = "ID396978_oopbooks";
    $DB_PORT = "3306";

    try {
        $db = new PDO('mysql:host=' . $DB_HOST . '; port=' . $DB_PORT . '; dbname=' . $DB_DB, $DB_USER, $DB_PASSWORD);
    } catch (PDOException $e) {
        echo "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);

    return $db;
}