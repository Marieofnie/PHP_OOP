/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./src/index.php"],
	theme: {
		extend: {},
	},
	plugins: [],
};
